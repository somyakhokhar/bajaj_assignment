package com.example.Spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SomyaKhokharApplication {

	public static void main(String[] args) {
		SpringApplication.run(SomyaKhokharApplication.class, args);
	}

}
