package com.example.Spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SomyaKhokharApplicationTests {

	@Test
	void contextLoads() {
	}

}
